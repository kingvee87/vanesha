from .core import Kaskus
